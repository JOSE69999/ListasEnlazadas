
package tarealista;


public class Lista {
    private Nodo primero;

    public Lista() {
        primero = null;
    }

    public Nodo leerPrimero() {
        return primero;
    }

    public void insertarCabezaLista(int entrada) {
        Nodo nuevo = new Nodo(entrada);
        nuevo.enlace = primero;
        primero = nuevo;
    }

    public void insertarLista(Nodo anterior, int entrada) {
        Nodo nuevo = new Nodo(entrada);
        nuevo.enlace = anterior.enlace;
        anterior.enlace = nuevo;
    }

    public void eliminar(int entrada) {
        Nodo actual = primero;
        Nodo anterior = null;
        
        while (actual != null && actual.dato != entrada) {
            anterior = actual;
            actual = actual.enlace;
        }
        
        if (actual != null) {
            if (actual == primero) {
                primero = actual.enlace;
            } else {
                anterior.enlace = actual.enlace;
            }
            actual = null;
        }
    }

    public Nodo buscarLista(int destino) {
        Nodo indice;
        for (indice = primero; indice != null; indice = indice.enlace) {
            if (indice.dato == destino) {
                return indice;
            }
        }
        return null;
    }

    public void visualizar() {
        Nodo n = primero;
        while (n != null) {
            System.out.print(n.dato + " ");
            n = n.enlace;
        }
    }

    // Método 1: Invertir la lista
    public void invertir() {
        Nodo anterior = null;
        Nodo actual = primero;
        Nodo siguiente;
        
        while (actual != null) {
            siguiente = actual.enlace;
            actual.enlace = anterior;
            anterior = actual;
            actual = siguiente;
        }
        
        primero = anterior;
    }

    // Método 2: Obtener el elemento n desde el final
    public Nodo obtenerElementoDesdeFinal(int n) {
        Nodo primeroTemp = primero;
        Nodo segundoTemp = primero;

      
        for (int i = 0; i < n; i++) {
            if (primeroTemp == null) {
                return null;  
            }
            primeroTemp = primeroTemp.enlace;
        }

      
        while (primeroTemp != null) {
            primeroTemp = primeroTemp.enlace;
            segundoTemp = segundoTemp.enlace;
        }

        return segundoTemp;  
    }

    // Método 3: Eliminar duplicados
    public void eliminarDuplicados() {
        Nodo actual = primero;
        
        while (actual != null) {
            Nodo siguiente = actual;
            while (siguiente != null && siguiente.enlace != null) {
                if (actual.dato == siguiente.enlace.dato) {
                    siguiente.enlace = siguiente.enlace.enlace;  
                } else {
                    siguiente = siguiente.enlace;
                }
            }
            actual = actual.enlace;
        }
    }

    // Método 4: Obtener el tamaño de la lista
    public int obtenerTamaño() {
        int tamaño = 0;
        Nodo actual = primero;
        
        while (actual != null) {
            tamaño++;
            actual = actual.enlace;
        }
        
        return tamaño;
    }
}
