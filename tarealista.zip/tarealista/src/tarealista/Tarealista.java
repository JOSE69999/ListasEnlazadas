
package tarealista;


public class Tarealista {
     private Nodo primero;  

    
    public Tarealista() {
        primero = null;
    }

    
    public void insertarCabezaLista(int entrada) {
        Nodo nuevo = new Nodo(entrada);  
        nuevo.enlace = primero;          
        primero = nuevo;               
    }

    // Muestra todos los elementos de la lista
    public void visualizar() {
        Nodo n = primero;
        while (n != null) {
            System.out.print(n.dato + " ");
            n = n.siguiente();  
        }
    }

    // Elimina un nodo con el valor dado
    public void eliminar(int entrada) {
        Nodo actual = primero;
        Nodo anterior = null;

        while (actual != null && actual.dato != entrada) {
            anterior = actual;
            actual = actual.siguiente();
        }

        if (actual != null) {
            if (anterior == null) {
                primero = actual.siguiente();  
            } else {
                anterior.enlace = actual.siguiente();  
            }
        }
    }

    // Buscar un nodo con el valor dado
    public Nodo buscarLista(int destino) {
        Nodo actual = primero;
        while (actual != null) {
            if (actual.dato == destino) {
                return actual;  
            }
            actual = actual.siguiente();
        }
        return null;  
    }

    
    public void ordenarAscendente() {
        if (primero == null || primero.siguiente() == null) {
            return;  
        }

        boolean intercambio;
        do {
            Nodo actual = primero;
            Nodo anterior = null;
            Nodo siguiente = primero.siguiente();
            intercambio = false;

            while (siguiente != null) {
                if (actual.dato > siguiente.dato) {
                    
                    int temp = actual.dato;
                    actual.dato = siguiente.dato;
                    siguiente.dato = temp;
                    intercambio = true;
                }
                actual = siguiente;
                siguiente = siguiente.siguiente();
            }
        } while (intercambio);
    }

    // Unir dos listas enlazadas
    public void unirListas(Tarealista lista2) {
        if (lista2.primero == null) {
            return;  
        }

        Nodo ultimo = primero;
        if (ultimo == null) {
            primero = lista2.primero;  
        } else {
            while (ultimo.siguiente() != null) {
                ultimo = ultimo.siguiente();
            }
            ultimo.enlace = lista2.primero;  
        }
    }

  
    public void separarParesEImpares(Tarealista pares, Tarealista impares) {
        Nodo actual = primero;
        while (actual != null) {
            if (actual.dato % 2 == 0) {
                pares.insertarCabezaLista(actual.dato);  
            } else {
                impares.insertarCabezaLista(actual.dato);  
            }
            actual = actual.siguiente();
        }
    }

   
    public static void main(String[] args) {
       
        Tarealista lista = new Tarealista();
        lista.insertarCabezaLista(1);
        lista.insertarCabezaLista(2);
        lista.insertarCabezaLista(3);
        lista.insertarCabezaLista(4);
        lista.insertarCabezaLista(5);
        lista.insertarCabezaLista(6);

        // Mostrar la lista original
        System.out.println("Lista original:");
        lista.visualizar();
        System.out.println("\n");

        // Eliminar un nodo
        lista.eliminar(3);
        System.out.println("Lista despues de eliminar 3:");
        lista.visualizar();
        System.out.println("\n");

        // nodo con el valor 4
        Nodo dato = lista.buscarLista(4);
        System.out.println("Dato encontrado: " + dato.dato);
        System.out.println("\n");

        //valor 10 después del nodo con valor 4
        lista.insertarCabezaLista(10);
        System.out.println("Lista despues de insertar 10:");
        lista.visualizar();
        System.out.println("\n");

        // Ordenar la lista de forma ascendente
        lista.ordenarAscendente();
        System.out.println("Lista ordenada ascendentemente:");
        lista.visualizar();
        System.out.println("\n");

        // Crear una segunda lista
        Tarealista lista2 = new Tarealista();
        lista2.insertarCabezaLista(8);
        lista2.insertarCabezaLista(7);
        lista2.insertarCabezaLista(6);
        lista2.insertarCabezaLista(5);

        // Mostrar la segunda lista
        System.out.print("Lista 2: ");
        lista2.visualizar();
        System.out.println("\n");

        // Unir las dos listas
        lista.unirListas(lista2);
        System.out.println("Lista unida:");
        lista.visualizar();
        System.out.println("\n");

        // Crear listas para números pares e impares
        Tarealista pares = new Tarealista();
        Tarealista impares = new Tarealista();
        lista.separarParesEImpares(pares, impares);

        // Mostrar lista de números pares
        System.out.println("Lista de numeros pares:");
        pares.visualizar();
        System.out.println("\n");

        // Mostrar lista de números impares
        System.out.println("Lista de numeros impares:");
        impares.visualizar();
    }
}
    
    

