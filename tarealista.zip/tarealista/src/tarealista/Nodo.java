
package tarealista;


public class Nodo {

    int dato;     
    Nodo enlace;  

   
    public Nodo(int x) {
        dato = x;
        enlace = null;  
    }


    public Nodo(int x, Nodo n) {
        dato = x;
        enlace = n;
    }

    // Método para obtener el dato del nodo
    public int leerDato() {
        return dato;
    }

    // Método para obtener el siguiente nodo
    public Nodo siguiente() {
        return enlace;
    }

    // Método para representar el nodo en formato String
    @Override
    public String toString() {
        return dato + " => " + enlace; 
    }
}
